package com.nhcar.utils;

public class Const {
    public  static final String SERVER_URL="http://110.64.48.115:8080/";
    public  static final String PIC_URL="uploads/";
    public  static final String SERVLET_URL="android/";

}
